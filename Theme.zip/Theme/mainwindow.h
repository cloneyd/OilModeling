#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtWebEngineCore>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_sfws_btn_clicked();

    void on_load_site_BTN_clicked();

    void on_pencil_1_BTN_clicked();

    void on_grid_flag_BTN_clicked();

private:
    Ui::MainWindow *ui;
    bool gridFlagBTN;
};
#endif // MAINWINDOW_H
