#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QString p = "@59.9448043,30.3622528,9.83z";
ui->preview->load(QUrl("http://www.google.ru/maps/"+p));
ui->preview->show();
gridFlagBTN = true;
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_sfws_btn_clicked()
{
 ui->preview->showFullScreen();
}

void MainWindow::on_load_site_BTN_clicked()
{


double X_ = ui->X_SB->value();
double Y_ = ui->Y_SB->value();
double Scale_ = ui->Scale_SB->value();

QString X = QString::number(X_);
QString Y = QString::number(Y_);
QString Scale = QString::number(Scale_);

QString add = "@" + X + "," + Y + "," + Scale + "z";

switch ( ui->map_type_CB->currentIndex()) {
case 0:
    ui->preview->load(QUrl("http://www.google.ru/maps/"+add));
    ui->preview->show();

    break;

case 1:
    ui->preview->load(QUrl("http://www.google.ru/maps/"+add));
    ui->preview->show();
    break;

case 2:
    ui->preview->load(QUrl("http://www.google.ru/maps/"+add));
    ui->preview->show();
    break;

default:

    break;
}

}

void MainWindow::on_pencil_1_BTN_clicked()
{
    auto image {ui->preview};
    QPixmap pixm(ui->preview->size());
    QPainter pr(&pixm);
    ui->preview->render(&pr);
ui->red_map_handle->show();


}

void MainWindow::on_grid_flag_BTN_clicked()
{
    if (gridFlagBTN == true){
        ui->grid_flag_BTN->setText("Выключить сетку");
        gridFlagBTN = false;
    }else{
        ui->grid_flag_BTN->setText("Включить сетку");
        gridFlagBTN = true;
    }
}
