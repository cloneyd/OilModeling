#include "mainwindow.h"

#include <QApplication>
#include <QStyleFactory>
#include <QFile>
#include <QIODevice>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QFile styleF("C:/Users/Klyaz/Downloads/QSS-master/QSS-master/ManjaroMix.qss");
    styleF.open(QFile::ReadOnly);
    QString styleSheet = QLatin1String(styleF.readAll());
    a.setStyleSheet(styleSheet);

    MainWindow w;
    w.show();
    return a.exec();
}
