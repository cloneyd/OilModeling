#ifndef PCH_HPP
#define PCH_HPP

#include <QVector>
#include <QPointF>
#include <utility>
#include <QString>

#endif // PCH_HPP
