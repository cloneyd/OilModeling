#ifndef GRID_HANDLER_UTILITIES_HPP
#define GRID_HANDLER_UTILITIES_HPP

double toRealMetres(double pixels);
double fromRealMetres(double metres);

#endif // GRID_HANDLER_UTILITIES_HPP
